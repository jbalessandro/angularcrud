export class RetornoUpdate {
    recalcular: boolean;
    erros: string[];
}