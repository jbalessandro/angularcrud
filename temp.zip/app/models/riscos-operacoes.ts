export class RiscosOperacoes {
   identificacao: string;
   tipoCliente: string;
   empresa: string;
   raiting: string;
   modalidade: string;
   valorInicial: number;
   riscoAtual: number;
   riscoVencido: number;
}