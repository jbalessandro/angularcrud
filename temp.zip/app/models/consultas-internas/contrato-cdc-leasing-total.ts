export class ContratoCdcLeasingTotal {
    contratosCdc: number;
    contratosLea: number;
    contratosAtivos: number;
    contratosLiquidados: number;
    contratosLiquidadosAntecipados: number;
    saldoContabilTotal: number;
    saldoEmAtraso: number;
    saldoPago: number;
    maximoEmAtrasoDoCpf: number;
}