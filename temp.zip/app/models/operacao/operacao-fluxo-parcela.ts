export class OperacaoFluxoParcela {
    parcela: number;
    vencimento: string;
    valorParcela: number;
    balao: string;
}