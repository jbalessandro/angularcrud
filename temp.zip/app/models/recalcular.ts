export class Recalcular {
    idProposta: string;
    observacao: string;
}