export class MesaUsuario {
    codigo: string;
    nome: string;
}