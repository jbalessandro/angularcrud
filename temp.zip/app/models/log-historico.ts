export class LogHistorico {
    campo: string;
    anterior: string;
    novo: string;
    dtAlteracao: Date;
    usuario: string;
    edicaoAtual: boolean;
    parecerComercial: string;
    parecerInterno: string;
    dtInclusao?: Date;
    dtAgendamento?: Date;
    motivos: string[];
    tempoAdicionado: number;
}