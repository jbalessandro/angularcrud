export class PerfilEnderecoCorrespondencia {
    idCliente: number;
    sqEndereco: number;
    logradouro: string;
    numero: string;
    complemento: string;
    bairro: string;
    cidade: string;
    idEstado: string;
    cep: string;
}