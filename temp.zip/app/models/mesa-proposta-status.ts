export class MesaPropostaStatus {
    status: string;
    ultimoUsuario: string;
    ultimaAnalise: Date;
    idProposta: string;
}