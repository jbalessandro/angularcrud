export class InfoAnalise {
    tempoAnalise: string;
    usuario: string;
    alcada: string;
}