export class ParecerPendencia {
    idPendencia: string;
    dsPendencia: string;
    flPagamento: boolean;
    flPendencia: boolean;
    idCompromisso: number;
    selIdCompromissao: number;
    selIdPendencia: number;
    selFlPendencia: number;
    obrigatorio: boolean;
}