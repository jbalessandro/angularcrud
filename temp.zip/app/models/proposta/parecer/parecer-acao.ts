export class ParecerAcao {
  idAcao: number;
  dsAcao: string;   
}