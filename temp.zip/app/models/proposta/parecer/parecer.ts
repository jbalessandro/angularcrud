export class Parecer {
    idProposta: string;   
    idAcao: number;    
    observacao: string;
    parecerObservacao: string;
}