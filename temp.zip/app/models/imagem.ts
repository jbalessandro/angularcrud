export class Imagem {
    data: string;
}