export class PropostaAcompanhamento {
    dtEntrada: Date;
    dtSaida: Date;
    motivo: string;
    tempo: string;
    usuario: string;
}