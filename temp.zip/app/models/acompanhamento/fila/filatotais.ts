export class FilaTotais {    
    id_fila: number
    ds_mesa : string
    id_catalogo : string
    nm_fila : string
    qtd_fila : number  
    qtd_emanalise : number 
    qtd_usuarios_fila : number 
    qtd_usuarios_analise : number 
    qtd_total_usuarios : number 
}