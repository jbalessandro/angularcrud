export class FilaPropostaDecidida{
    idPropostaDecisao: number;
    dsPropostaDecisao: string;
    qtde: number;
}