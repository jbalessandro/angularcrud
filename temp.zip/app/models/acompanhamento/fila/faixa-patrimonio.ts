export class FaixaPatrimonio {
    idClienteFaixaPatrimonio: number;
    dsClienteFaixaPatrimonio: string;
}