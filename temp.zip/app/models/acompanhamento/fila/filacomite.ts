export class FilaComite {
    id_proposta: string;
    ds_proposta: string;
    id_cliente: number;
    nm_cliente_rsoc: string;
    id_prioridade: string;
    ds_motivo: string;
    id_fila: string;
    id_pessoa: string;
    ds_tipo_motivo: string;
    fl_mensagens: string;
    fl_retorno: string;
    id_servico: string;
    id_catalogo: string;
    id_status_analise: string;
    dt_inclusao: Date;
    cargo_1: string;
    usuario_1: string;
    data_1: Date;
    cargo_2: string;
    usuario_2: string;
    tp_mesa: string;
    data_2: Date;
}