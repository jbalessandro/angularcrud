export class Agendamento {
    idProposta: string;
    idMotivo: number;
    dtAgendamento: Date;
    parecer: string;
    observacao: string;
    tempoAdicionado: number;
}