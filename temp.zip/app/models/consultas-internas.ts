export class ConsultasInternas {
   tipo: string;
   tipoCliente: string;
   identificacao: string;
   dataConsulta: Date;
   consulta: string;
   restricao: string;
}