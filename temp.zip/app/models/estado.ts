export class Estado {
    codigo: string;
    descricao: string;
}