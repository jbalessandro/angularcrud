export class SerasaRestricao {
    data: Date;
    modalidade: string;
    instituicao: string;
    valor: number;
}