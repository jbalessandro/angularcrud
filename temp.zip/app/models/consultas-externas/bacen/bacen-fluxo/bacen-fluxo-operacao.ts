export class BacenFluxoOperacao {
    dataBase: Date;
    situacaoProcIfs: number;
    situacaoProcValor: number;
    qtdOperacoes: number;
    qtdIfsComOperacoes: number;
    dtInicioOperacao: Date;
}