import { BacenModalidadeValor } from "./bacen-modalidade-valor";

export class BacenOutroCredito {
    descricao: string;
    valores: BacenModalidadeValor[];
}