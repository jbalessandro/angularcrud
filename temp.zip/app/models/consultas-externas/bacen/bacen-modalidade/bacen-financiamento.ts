import { BacenModalidadeValor } from "./bacen-modalidade-valor";

export class BacenFinanciamento {
    descricao: string;
    valores: BacenModalidadeValor[];
}