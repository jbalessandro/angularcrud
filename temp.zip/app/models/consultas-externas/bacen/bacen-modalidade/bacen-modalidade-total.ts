export class BacenModalidadeTotal {
    dataBase: Date;
    total: number;
}