export class BacenModalidadeDataBase {
    dataBase: Date;
}