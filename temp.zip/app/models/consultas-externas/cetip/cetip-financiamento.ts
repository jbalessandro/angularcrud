import { CetipBem } from "./cetip-bem";
import { CetipInstituicao } from "./cetip-instituicao";

export class CetipFinanciamento {
    bem: CetipBem;
    instituicao: CetipInstituicao;
}