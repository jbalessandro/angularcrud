export class Portal {
    instituicao: string;
    nome: string;
    historicoDeAfastamento: boolean;
    primeiraRemuneracaoBasicaBruta: number;
    segundaRemuneracaoBasicaBruta: number;
    terceiraRemuneracaoBasicaBruta: number;
}