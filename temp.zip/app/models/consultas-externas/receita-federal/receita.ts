export class Receita {
    cpf: string;
    nome: string;
    situacaoCadastral: string;
    dtInscricao: Date;
}