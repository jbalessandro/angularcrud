enum SituacaoPagamento {
    VisaoGeral = 1,
    AVencer = 2,
    Vencido = 3,
    Prejuizo = 4
}