export class ConselhoRegional {
    conselho: string;
    registro: string;
    uf: string;
    situacao: string;
}