import { BureauFonteRenda } from "./bureau-fonte-renda";
import { BureauFontePagadora } from "./bureau-fonte-pagadora";

export class BureauRenda {
    fonteRenda: BureauFonteRenda[];
    fontePagadora: BureauFontePagadora[];
}