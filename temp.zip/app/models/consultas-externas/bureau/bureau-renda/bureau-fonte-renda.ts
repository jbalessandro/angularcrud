export class BureauFonteRenda {
    fonte: string;
    renda: number;
    variacao: number;
    faixaRenda: string;
}