export class BureauFontePagadora {
    fonte: string;
    fontePagadora: string;
    renda: number;
    referencia: Date;
}