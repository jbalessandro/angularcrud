export class BureauParentesco {
    fonte: string;
    vinculo: string;
    cpf: string;
    nome: string;
}