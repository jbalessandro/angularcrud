import { BureauSimilaridadeValor } from "./bureau-similaridade-valor";

export class BureauSimilaridade {
    similaridade: string;
    valores: BureauSimilaridadeValor[];
}