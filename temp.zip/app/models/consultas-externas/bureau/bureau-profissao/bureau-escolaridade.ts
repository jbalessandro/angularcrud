export class BureauEscolaridade {
    origem: string;
    escolaridade: string;    
}