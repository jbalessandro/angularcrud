import { Component, Input } from '@angular/core';

@Component({
    selector: 'logo',
    templateUrl: './logo.component.html',
    styleUrls: []
})


export class LogoComponent {
}