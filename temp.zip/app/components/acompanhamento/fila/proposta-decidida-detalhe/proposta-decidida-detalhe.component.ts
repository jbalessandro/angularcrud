import { Component, Input, OnInit } from '@angular/core';
import { FilaCreditoService } from './../../../../services/fila-credito/fila-credito.service';
import { DetalhePropostaDecidida } from '../../../../models/acompanhamento/fila/detalhe-proposta-decidida';

@Component({
    selector: 'proposta-decidida-detalhe',
    templateUrl: './proposta-decidida-detalhe.component.html',
    providers: [ FilaCreditoService]
})
export class PropostaDecididaDetalheComponent implements OnInit {
    @Input() idCliente: string;
    @Input() idDecisao: number;
    loading: boolean = false;
    isOpen: boolean = false;
    propostaDecididaDetalhe: DetalhePropostaDecidida;
    exibirModal: boolean = false;
    mensagem: string = "";
    
    constructor(private filaCreditoService: FilaCreditoService){ }

    ngOnInit(): void {
        this.getPropostaDecididaDetalhe();
    }

    fecharModal(fecharModal: boolean) {
        this.exibirModal = fecharModal;
    }

    private getPropostaDecididaDetalhe() {       
        this.loading = true;
        this.filaCreditoService.getPropostaDecididaDetalhe(this.idDecisao, 0,"-", this.idCliente).subscribe(
            data => {
                this.propostaDecididaDetalhe = data;
                debugger;
            },
            error => {
                debugger;
                this.loading = false;
                () => this.loading = false;
            }
        )       
    }

}