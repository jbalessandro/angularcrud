import { Component } from '@angular/core';

@Component({
    selector: 'consultas-internas-posicao-investidor',
    templateUrl: './consultas-internas-posicao-investidor.component.html'
})

export class ConsultasInternasPosicaoInvestidorComponent{
}