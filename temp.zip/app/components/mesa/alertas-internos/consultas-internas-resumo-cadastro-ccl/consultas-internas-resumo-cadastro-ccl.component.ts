import { Component } from '@angular/core';

@Component({
    selector: 'consultas-internas-resumo-cadastro-ccl',
    templateUrl: './consultas-internas-resumo-cadastro-ccl.component.html'
})

export class ConsultasInternasResumoCadastroCCLComponent {
}