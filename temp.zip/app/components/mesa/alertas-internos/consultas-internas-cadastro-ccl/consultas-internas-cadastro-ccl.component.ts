import { Component } from '@angular/core';

@Component({
    selector: 'consultas-internas-cadastro-ccl',
    templateUrl: './consultas-internas-cadastro-ccl.component.html'
})

export class ConsultasInternasCadastroCCLComponent {

}