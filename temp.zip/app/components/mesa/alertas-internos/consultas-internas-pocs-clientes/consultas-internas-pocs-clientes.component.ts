import { Component } from '@angular/core';

@Component({
    selector: 'consultas-internas-pocs-clientes',
    templateUrl: './consultas-internas-pocs-clientes.component.html'
})

export class ConsultasInternasPocsClientesComponent {
}