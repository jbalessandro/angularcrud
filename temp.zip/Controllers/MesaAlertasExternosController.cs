using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ServicesReference.MesaAlertasExternosService;

namespace Mesa.Controllers
{
    [Authorize]
    [Route("api/MesaAlertasExternos")]
    public class MesaAlertasExternosController : Controller
    {
        private MesaAlertasExternosServiceClient service;

        public MesaAlertasExternosController() {
            this.service = ServiceFactory.Get<MesaAlertasExternosServiceClient>("MesaAlertasExternosService");
        }
        
        // api/MesaAlertasExternos/v1/GetAlertas/MFLTE
        [Route("v1/GetAlertas/{idProposta}")]
        [HttpGet]
        public async Task<IActionResult> GetAlertas(string idProposta)
        {            
            var model = await service.GetAlertasAsync(idProposta);
            return Ok(model);
        }

        // api/MesaAlertasExternos/v1/SetResolucao/MFLTE/1/1
        [Route("v1/SetResolucao/{idProposta}/{id}/{codCompromisso}")]
        [HttpGet]
        public async Task<IActionResult> SetResolucao(string idProposta, int id, int codCompromisso)
        {            
            var model = await service.SetResolucaoAsync(new AlertaResolvido {
                Id = id,
                IdProposta = idProposta,
                CodCompromisso = codCompromisso,
                CodUsuario = HttpContext.User.Claims.Where(x => x.Type == ClaimTypes.Sid).FirstOrDefault().Value
            });
            return Ok(model);
        }
    }
}